const selectElement = document.querySelector('.selectop > selectop');
        selectElement.addEventListener('change', (event) => {
          const elegido = event.target.value;
          if (elegido === 'T') {

          } else if (elegido === 'In') {
            
          } else if (elegido === 'Va') {

          } else if (elegido === 'Bl') {

          }
        });