const selectElement = document.querySelector('.select > select');
        selectElement.addEventListener('change', (event) => {
          const elegido = event.target.value;
          if (elegido === 'Z') {

          } else if (elegido === 'A') {
            
          } else if (elegido === 'B') {

          } else if (elegido === 'C') {

          } else if (elegido === 'D') {

          } else if (elegido === 'E') {

          }
        });