const signInBtnLink = document.querySelector('signInBtn-Link');
const signInBtnLink = document.querySelector('signUpBtn-Link');
 wrapper = document.querySelector('.wrapper');

signInBtnLink.addEventListener('click', () => { wrapper.classList.toggle('active');
});